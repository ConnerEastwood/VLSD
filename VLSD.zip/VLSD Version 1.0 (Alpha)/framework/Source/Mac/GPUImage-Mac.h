#import <Cocoa/Cocoa.h>

//! Project version number for GPUImage-Mac.
FOUNDATION_EXPORT double GPUImage_MacVersionNumber;

//! Project version string for GPUImage-Mac.
FOUNDATION_EXPORT const unsigned char GPUImage_MacVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GPUImage_Mac/PublicHeader.h>


