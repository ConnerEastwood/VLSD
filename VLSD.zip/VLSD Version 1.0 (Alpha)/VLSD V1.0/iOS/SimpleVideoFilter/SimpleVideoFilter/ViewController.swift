import UIKit
import CoreImage
import GPUImage
import AVFoundation

class ViewController: UIViewController {
    @IBOutlet weak var renderView: RenderView!
   
    let fbSize = Size(width: 1024, height: 768)
 
    let Saturation = SaturationAdjustment()
    let Smoothtoon = SmoothToonFilter()
    let toonFilter = ToonFilter()
    let swirl = SwirlDistortion()
    let Bulge = BulgeDistortion()
    let Brightness = BrightnessAdjustment()
    let Exposure = ExposureAdjustment()
    var Contrast = ContrastAdjustment()
    let Gamma = GammaAdjustment()
    let pinch = PinchDistortion()
    let Levels = LevelsAdjustment()
    let Matrix = ColorMatrixFilter()
    let blendFilter = AlphaBlend()
    let kuwa = KuwaharaFilter()
    let rgb = RGBAdjustment()
    let Haze = HazeFragmentShader
    let Vibrance = VibranceFragmentShader
    let Lowpass = LowPassFilter()
    let highpass = HighPassFilter()
    let tiltshift = TiltShift()
    let vignette = Vignette()
    let stretch = StretchDistortion()
    var camera:Camera!
    var bulgeLevel:Float!
    var bulgeInc:Float!

    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        bulgeLevel = 0;
        bulgeInc = 0.01;
        do {
            
            
            
            camera = try Camera(sessionPreset:AVCaptureSessionPreset1920x1080)
           // camera.runBenchmark = true
            camera.delegate = self
            //set up the filter flow
            //bulge.radius = 2.0
            
            //set up the filter flow
            Bulge.radius = -0.1
            //pinch.radius = 0.1
            //Contrast.contrast = 1.5
            //Brightness.brightness = 0
            //Exposure.exposure = 0.5
            //saturationFilter.saturation = 1
            
            Saturation.saturation = 1.8
            Brightness.brightness = 0
            Contrast.contrast = 2
            Exposure.exposure = 0.1
            Lowpass.strength = 0.5
            vignette.start = 0.7
            pinch.scale =  0.6
            //Bulge.radius = 0.3
            // ask pete how to stop it from expanding
        
            
            
            
           // Lowpass.strength = 0.5
            //Bulge.radius = -0.5
            stretch.backgroundColor = Color(red:100, green:20, blue:40)
            //Haze.distance(from: -3,0 to: 0)
            
            
            
            
            
            
            
            //Need to ask pete how to stop pinch moving
            //tiltshift.blurRadiusInPixels = 0.1
            
            
            
        
            
            
            
            
            
            //lowpass = LowPassFilter()
            //highpass = HighPassFilter()
            //tiltshift = TiltShift()
            //vignette = Vignette()
            
            
            
            camera --> pinch --> Brightness --> Saturation --> Contrast --> Exposure --> Lowpass --> renderView
            
            
            
            
            camera.startCapture()
        } catch {
            fatalError("Could not initialize rendering pipeline: \(error)")
        }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
    }

    override var prefersStatusBarHidden: Bool {
        return true
    }  
   
}

extension ViewController: CameraDelegate {
    func didCaptureBuffer(_ sampleBuffer: CMSampleBuffer) {
        print("hello")
        bulgeLevel = bulgeLevel+bulgeInc
        
        if(bulgeLevel > 2 || bulgeLevel < 0){
            bulgeInc = bulgeInc * -1
        }
        //change this to filter being used
        //pinch.radius = bulgeLevel

           }

  }
